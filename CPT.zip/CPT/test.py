# Right of the player:  player.getX() + player.getWidth()
# Left of the player:   player.getX()
# Top of the player:    player.getY() - player.getHeight() + 2
# Bottom of the player: player.getY() + 2

# Right of the block:   blocksList[counter].getX() + blocksList[counter].getWidth()
# Left of the block:    blocksList[counter].getX()
# Top of the block:     blocksList[counter].getY()
# Bottom of the block:  blocksList[counter].getY() + blocksList[counter].getHeight()